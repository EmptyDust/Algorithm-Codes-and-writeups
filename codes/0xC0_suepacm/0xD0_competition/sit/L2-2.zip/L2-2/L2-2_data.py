from random import randint

t = 1
print(t)
sum=0
for __ in range(t):
    n = 10**6#randint(1,10**6)
    m = 10**6#randint(1,10**6)

    k = randint(1,min(n*m,10**6))
    print(f'{n} {m} {k}')

    for _ in range(n):
        a = randint(1,10**7)
        print(a,end=' ')
    print()
    for _ in range(m):
        b = randint(1,10**7)
        print(b,end=' ')
    print()
    sum+=k
# print(sum)